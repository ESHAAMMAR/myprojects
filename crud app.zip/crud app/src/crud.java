import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

class crud {
    private JPanel Main;
    private JButton Save;
    private JTable table1;
    private JButton Update;
    private JButton delete;
    private JButton searchButton;
    private JTextField txtSalaryTextField;
    private JTextField txtNumberTextField;
    private JTextField txtId;
    private JTextField txtName;

    Connection con;

    public static void main(String[] args) {
        JFrame frame = new JFrame("crud");
        frame.setContentPane(new crud().Main);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    public crud() {
        connect();

        Save.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveEmployee();
                initializeTable();
            }
        });

        Update.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateEmployee();
                initializeTable();
            }
        });

        delete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteEmployee();
                initializeTable();
            }
        });

        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                searchEmployee();
            }
        });

        initializeTable();
    }

    public void connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/employees?allowPublicKeyRetrieval=true&useSSL=false", "root", "Ware(esha)2024");
            System.out.println("Connected");
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void initializeTable() {
        try {
            String query = "SELECT * FROM employee";
            PreparedStatement pst = con.prepareStatement(query);
            ResultSet rs = pst.executeQuery();

            DefaultTableModel model = new DefaultTableModel();
            table1.setModel(model);

            model.addColumn("ID");
            model.addColumn("Name");
            model.addColumn("Salary");
            model.addColumn("Phone Number");

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getDouble("salary"),
                        rs.getString("phone_number")
                });
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void saveEmployee() {
        String name = txtName.getText();
        String salary = txtSalaryTextField.getText();
        String phone = txtNumberTextField.getText();

        try {
            PreparedStatement pst = con.prepareStatement("INSERT INTO employee(name, salary, phone_number) VALUES (?, ?, ?)");
            pst.setString(1, name);
            pst.setString(2, salary);
            pst.setString(3, phone);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Record Added!");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void updateEmployee() {
        String id = txtId.getText();
        String fieldToUpdate = JOptionPane.showInputDialog("Enter field to update (name, salary, phone_number):");

        // Check if fieldToUpdate is null (user canceled the input dialog)
        if (fieldToUpdate == null) {
            return;
        }

        String newValue = JOptionPane.showInputDialog("Enter new value:");

        // Check if newValue is null or empty
        if (newValue == null || newValue.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Invalid input for new value!");
            return;
        }

        try {
            String query = "UPDATE employee SET " + fieldToUpdate + " = ? WHERE id = ?";
            PreparedStatement pst = con.prepareStatement(query);

            // Handle different types of fields
            if (fieldToUpdate.equals("salary")) {
                try {
                    pst.setDouble(1, Double.parseDouble(newValue));
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "Invalid input for salary!");
                    return;
                }
            } else {
                pst.setString(1, newValue);
            }

            pst.setInt(2, Integer.parseInt(id));
            int rowsUpdated = pst.executeUpdate();

            if (rowsUpdated > 0) {
                JOptionPane.showMessageDialog(null, "Record Updated!");
            } else {
                JOptionPane.showMessageDialog(null, "No such record found!");
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void deleteEmployee() {
        String idToDelete = JOptionPane.showInputDialog("Enter ID to delete:");

        try {
            PreparedStatement pst = con.prepareStatement("DELETE FROM employee WHERE id = ?");
            pst.setString(1, idToDelete);
            int rowsDeleted = pst.executeUpdate();
            if (rowsDeleted > 0) {
                JOptionPane.showMessageDialog(null, "Record Deleted!");
            } else {
                JOptionPane.showMessageDialog(null, "No such record found!");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void searchEmployee() {
        String id = txtId.getText();

        try {
            PreparedStatement pst = con.prepareStatement("SELECT * FROM employee WHERE id = ?");
            pst.setString(1, id);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                txtName.setText(rs.getString("name"));
                txtSalaryTextField.setText(String.valueOf(rs.getDouble("salary")));
                txtNumberTextField.setText(rs.getString("phone_number"));
            } else {
                JOptionPane.showMessageDialog(null, "No Record Found!");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}



