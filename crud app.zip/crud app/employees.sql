CREATE DATABASE employees;

USE employees;

CREATE TABLE employee (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50),
    salary DECIMAL(10, 2),
    phone_number VARCHAR(15)
);

