CREATE DATABASE mydatabase;

USE mydatabase;

CREATE TABLE employees (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50),
    salary DECIMAL(10, 2),
    phone_number VARCHAR(15)
);
